DokuWiki Integration Library
for
CodeIgniter

Tested on CodeIgniter 1.7.2, DokuWiki 2009-12-25c �Lemming� and PHP 5.2
==============================
Provides an integration point from DokuWiki to CodeIgniter,
allowing read-only DokuWiki markup to XHTML rendering within the CodeIgniter environment.

Included are their relative installation directories. 
No changes are required to the CI or DW base installs.

More information available on the blog.
Last updated: 5/11/2010
==============================
Plugin Author: Josh Carrier <josh@joshjcarrier.com>
Plugin Web: http://blog.joshjcarrier.com
Integration Author: J�r�me Jaglale
Integration Web: http://maestric.com/doc/php/integrate-dokuwiki-to-your-website