<?php

/* DokuWiki renderer: overrides some methods from Doku_Renderer_xhtml 
 * Author: J�r�me Jaglale
 * Source: http://maestric.com/wiki/doku.php?id=php:integrate-dokuwiki-to-your-website
 */

class Doku_Renderer_xhtml_export extends Doku_Renderer_xhtml {

	var $base_url;

	function set_base_url($url)
	{
		$this->base_url = $url;
	}

    function internallink($id, $name = NULL, $search=NULL,$returnonly=false)
	{
        global $conf;
        global $ID;

		$default = $id;

        // now first resolve and clean up the $id
        resolve_pageid(getNS($ID),$id,$exists);
        $name = $this->_getLinkTitle($name, $default, $isImage, $id);
        if ( !$isImage ) {    
            $class='wikilink1';
        } else {
            $class='media';
        }

        // don't keep hash anchor
		$hash = "";

        //prepare for formating
        $link['target'] = $conf['target']['wiki'];
        $link['style']  = '';
        $link['pre']    = '';
        $link['suf']    = '';

        // highlight link to current page
        if ($id == $ID) {
            $link['pre']    = '<span class="curid">';
            $link['suf']    = '</span>';
        }
        $link['more']   = '';
        $link['class']  = $class;

		// make links
		if ($class = 'wikilink2') {
			$link['url']    =  $this->base_url . $id;
		}
		else {
	        $link['url']    =  $this->base_url . $id;			
		}
        $link['name']   = $name;
        $link['title']  = $id;

        //add search string
        if($search){
            ($conf['userewrite']) ? $link['url'].='?s=' : $link['url'].='&amp;s=';
            $link['url'] .= rawurlencode($search);
        }

        //keep hash
        if($hash) $link['url'].='#'.$hash;

		//output formatted
        if($returnonly){
            return $this->_formatLink($link);
        }else{
            $this->doc .= $this->_formatLink($link);
        }
    }

    function internalmedia ($src, $title=NULL, $align=NULL, $width=NULL, $height=NULL, $cache=NULL, $linking=NULL)
	{
        global $conf;
        global $ID;
        resolve_mediaid(getNS($ID),$src, $exists);

        $link = array();
        $link['class']  = 'media';
        $link['style']  = '';
        $link['pre']    = '';
        $link['suf']    = '';
        $link['more']   = '';
        $link['target'] = $conf['target']['media'];
        $noLink = false;

        $link['title']  = $this->_xmlEntities($src);
        list($ext,$mime) = mimetype($src);
        if(substr($mime,0,5) == 'image'){
             $link['url'] = ml($src,array('id'=>$ID,'cache'=>$cache),($linking=='direct'));
             $linking ='nolink';
         }elseif($mime == 'application/x-shockwave-flash'){
             // don't link flash movies
             $noLink = true;
         }else{
             // add file icons
             $class = preg_replace('/[^_\-a-z0-9]+/i','_',$ext);
             $link['class'] .= ' mediafile mf_'.$class;
             $link['url'] = ml($src,array('id'=>$ID,'cache'=>$cache),true);
         }
         $link['name']   = $this->_media ($src, $title, $align, $width, $height, $cache);

         //output formatted
         if ($linking == 'nolink' || $noLink) $this->doc .= $link['name'];
         else $this->doc .= $this->_formatLink($link);
    }
}
