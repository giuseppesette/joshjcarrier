<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| DokuWiki installtion path
|--------------------------------------------------------------------------
|
| Must be an absolute system path. No trailing slash!
| e.g. /home/username/public_html/dokuwiki
|
*/

$config['dokuwiki_folder'] = '/home/joshjca1/public_html/wiki.joshjcarrier.com';

/*
|--------------------------------------------------------------------------
| DokuWiki url
|--------------------------------------------------------------------------
|
| Base URL used when accessing DokuWiki (for direct cache access)
| e.g. http://wiki.joshjcarrier.com
|
*/
$config['dokuwiki_url'] = 'http://wiki.joshjcarrier.com';

/*
|--------------------------------------------------------------------------
| Link prefix
|--------------------------------------------------------------------------
|
| Used when resolving DokuWiki internal links. Page id will be appended.
| Depending on your CodeIgniter integration level, you might even link to
| a CodeIgniter controller instead of the original DokuWiki.
| e.g. http://www.joshjcarrier.com/ or http://wiki.joshjcarrier.com/doku.php?id=
|
*/
$config['link_prefix'] = 'http://wiki.joshjcarrier.com/';
