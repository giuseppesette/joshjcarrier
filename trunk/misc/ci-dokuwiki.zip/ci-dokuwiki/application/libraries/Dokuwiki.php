<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter Dokuwiki Integration Class
 *
 * Inject your CodeIgniter pages with content from a DokuWiki installation
 * on the same server.
 *
 * @package        	CodeIgniter
 * @subpackage    	Libraries
 * @category    	Libraries
 * @author        	Josh Carrier
 * @link			http://www.joshjcarrier.com
 * @source			http://maestric.com/wiki/doku.php?id=php:integrate-dokuwiki-to-your-website
 * 					Adapted from J�r�me Jaglale's PHP script.
 * 					Modified with feedback given on J�r�me's website. 
 */
class Dokuwiki
{
	/* 
	 * Let's roll
	 * 		- J�r�me 
	 */
	 
	/**
	 * render - parses a DokuWiki page and returns the output
	 *
	 * @access	public
	 * @param	dokuPageId page id as used with the DokuWiki install. i.e. "start", "dokuwiki:start"
	 * @param	returnData if true, parsed output returned. Otherwise direct print out.
	 * @return	parsed DokuWiki output if $returnData is true
	 */
	function render($dokuPageId, $returnData = false)
	{
		global $config_cascade;
		global $conf;
		
		unset($_REQUEST['purge']);	// don't refresh caches
		
		// from id parameter, build text file path
		$pagePath = DOKU_PATH . '/data/pages/'. str_replace(":", "/", $dokuPageId) . '.txt';
		
		// get cached instructions for that file
		$cache = new cache_instructions($dokuPageId, $pagePath); 
		if ($cache->useCache()){ $instructions = $cache->retrieveCache(); } 
		else
		{ 
			$instructions = p_get_instructions(io_readfile($pagePath)); 
			$cache->storeCache($instructions); 
		}
		
		// create renderer
		require_once DOKU_INC . '/inc/parser/xhtml.php';
		require_once 'Doku_Renderer_xhtml_export.php';
		$renderer = & new Doku_Renderer_xhtml_export();
		
		// init renderer
		$renderer->set_base_url($this->_link_prefix);
		$renderer->smileys = getSmileys();
		// turn off table of contents
		$renderer->notoc();
		
		// set localizable items
		global $lang;
		$lang['toc'] = "Table of Contents";
		$lang['doublequoteopening']  = '�';
		$lang['doublequoteclosing']     = '�';
		
		// instructions processing
		$pageTitle = "";
		foreach ( $instructions as $instruction )
		{
			// get first level 1 header (optional)
			if ($pageTitle == "" && $instruction[0] == "header" && $instruction[1][1] == 1)
				$pageTitle = $instruction[1][0];
			
		    // render instruction
			call_user_func_array(array(&$renderer, $instruction[0]),$instruction[1]);
		}
		
		// get rendered html
		$html = $renderer->doc;
		
		// get metadata infos (optional)
		/* This feature not return by function, so removed.
		$date_creation = "";
		$date_modification = "";
		$metadata = p_get_metadata($dokuPageId);
		if (isset($metadata))
		{
			if (isset($metadata['date']))
			{
				$metadata_date = $metadata['date'];
				if (isset($metadata_date['created']))
				{
					$date_creation = date("F j, Y, g:i:s A", $metadata_date['created']);
				}
				if (isset($metadata_date['modified']))
				{
					$date_modification =date("F j, Y, g:i:s A", $metadata_date['modified']);
				}
			}
		}
		*/
		
		if(!$returnData)
		{
			return $html;
		}
		else
		{
			print $html;
		}
		
		return $html;
	}
	
	/**
	 * Constructor - Sets Preferences
	 *
	 * The constructor can be passed an array of config values
	 */
	function __construct($config = array())
	{
		if (!empty($config))
		{
			$this->initialize($config);
		}
	}
		
	/**
	 * Initialize preferences
	 *
	 * @access	public
	 * @param	array
	 * @return	void
	 */
	function initialize($config = array())
	{
		foreach ($config as $key => $val)
		{
			$this->{'_'.$key} = $val;
		}
 
		/* Initialization */
		global $config_cascade;
		$config_cascade = array(
			'main'=>array(), 'smileys'=>array(), 'acronyms'=>array(), 
			'entities'=>array(), 'scheme'=>array()
			);
		
		define('DOKU_PATH', $this->_dokuwiki_folder);
		define('DOKU_INC', DOKU_PATH . '/');
		define('DOKU_CONF', DOKU_PATH . '/conf/');
		define('DOKU_BASE', $this->_dokuwiki_url  . '/');
		
		global $conf;
		$conf['lockdir'] = DOKU_PATH . '/data/locks';
		$conf['datadir'] = DOKU_PATH . '/data';
		$conf['cachedir'] = DOKU_PATH . '/data/cache';
		$conf['mediadir'] = DOKU_PATH . '/data/media';
		$conf['metadir'] = DOKU_PATH . '/data/meta';
		$conf['maxseclevel'] = 0;	//links to edit sub-content
		$conf['target']['extern'] = '';
		require DOKU_CONF . 'dokuwiki.php';
		
		require DOKU_PATH . '/inc/parser/parser.php';
		require DOKU_PATH . '/inc/events.php';
		require DOKU_PATH . '/inc/mail.php';
		require DOKU_PATH . '/inc/cache.php';
	}
}
