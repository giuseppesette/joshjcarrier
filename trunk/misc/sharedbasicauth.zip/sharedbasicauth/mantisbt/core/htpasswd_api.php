<?php
# MantisBT - a php based bugtracking system

# MantisBT is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# MantisBT is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MantisBT.  If not, see <http://www.gnu.org/licenses/>.

/**
 * API for Apache HTPASSWD editing.
 * @package CoreAPI
 * @subpackage HTPASSWDAPI
 * @copyright Copyright (C) 2010 - 2010  Josh Carrier  - josh@joshjcarrier.com
 * @copyright Copyright (C) 2002 - 2010  MantisBT Team - mantisbt-dev@lists.sourceforge.net
 * @link http://www.mantisbt.org
 */

function htpasswd_modifiable() {
  return true;
}

function htpasswd_adduser( $p_username, $p_password ) {
	
	try{
	exec(sprintf(config_get('htpasswd_cmd_adduser'), $p_username, $p_password), $res);
	}
	catch(Exception $e)
	{
	echo 'ERROR CREATE. BASIC AUTH';
	}
	
}

function htpasswd_moduser( $t_username, $p_password ) {
	
	try{
	exec(sprintf(config_get('htpasswd_cmd_moduser'), $t_username, $p_password), $res);
	}
	catch(Exception $e)
	{
	echo 'ERROR UPDATE. BASIC AUTH';
	}
	
}

function htpasswd_deluser( $t_username, $p_password ) {
	
	try{
	exec(sprintf(config_get('htpasswd_cmd_moduser'), $t_username, $p_password), $res);
	}
	catch(Exception $e)
	{
	echo 'ERROR DELTE. BASIC AUTH';
	}
	
}