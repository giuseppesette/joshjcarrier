<?php
# MantisBT - a php based bugtracking system

# MantisBT is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option) any later version.
#
# MantisBT is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with MantisBT.  If not, see <http://www.gnu.org/licenses/>.

/**
 * @package MantisBT
 * @copyright Copyright (C) 2000 - 2002  Kenzaburo Ito - kenito@300baud.org
 * @copyright Copyright (C) 2002 - 2010  MantisBT Team - mantisbt-dev@lists.sourceforge.net
 * @link http://www.mantisbt.org
 */

# --- Database Configuration ---
$g_hostname = 'localhost';
$g_db_type = 'mysql';
$g_database_name = '';
$g_db_username = '';
$g_db_password = '';

# --- Anonymous Access / Signup ---
$g_allow_signup				= OFF;
$g_allow_anonymous_login	= ON;
$g_anonymous_account		= 'guest';

# --- Email Configuration ---
$g_phpMailer_method		= PHPMAILER_METHOD_MAIL; # or PHPMAILER_METHOD_SMTP, PHPMAILER_METHOD_SENDMAIL
$g_smtp_host			= 'smtp.gmail.com';			# used with PHPMAILER_METHOD_SMTP
$g_smtp_username		= '';					# used with PHPMAILER_METHOD_SMTP
$g_smtp_password		= '';					# used with PHPMAILER_METHOD_SMTP
$g_administrator_email  = '';
$g_webmaster_email      = '';
$g_from_name			= '';
$g_from_email           = '';	# the "From: " field in emails
$g_return_path_email    = '';	# the return address for bounced mail
$g_email_receive_own	= OFF;
$g_email_send_using_cronjob = OFF;

# --- Attachments / File Uploads ---
$g_allow_file_upload	= ON;
$g_file_upload_method	= DATABASE; # or DISK
$g_absolute_path_default_upload_folder = ''; # used with DISK, must contain trailing \ or /.
$g_max_file_size		= 5000000;	# in bytes
$g_preview_attachments_inline_max_size = 256 * 1024;
$g_allowed_files		= '';		# extensions comma separated, e.g. 'php,html,java,exe,pl'
$g_disallowed_files		= '';		# extensions comma separated

# --- Branding ---
$g_window_title			= 'MantisBT';
$g_logo_image			= 'images/mantis_logo.gif';
$g_favicon_image		= 'images/favicon.ico';

# --- Real names ---
$g_show_realname = OFF;
$g_show_user_realname_threshold = NOBODY;	# Set to access level (e.g. VIEWER, REPORTER, DEVELOPER, MANAGER, etc)

# --- Others ---
$g_default_home_page = 'my_view_page.php';	# Set to name of page to go to after login

#####################
# Wiki Integration
#####################

# Wiki Integration Enabled?
$g_wiki_enable = ON;

# Wiki Engine
$g_wiki_engine = 'dokuwiki';

# Wiki namespace to be used as root for all pages relating to this mantis installation.
$g_wiki_root_namespace = 'project';

# URL under which the wiki engine is hosted.  Must be on the same server.
$g_wiki_engine_url = 'http://wiki.joshjcarrier.com/';
$g_cookie_domain = '.joshjcarrier.com';

#####################
# htpasswd_api Integration
#####################

# Apache htpasswd Integration Enabled?
$g_htpasswd_enable = ON;

# htpasswd command client
$g_htpasswd_bin = 'htpasswd';
$g_htpasswd_file = '/home/jcarrier/.htpasswds/users';

# htpasswd create format
# \%1$s = username, \%2$s = password
$g_htpasswd_cmd_adduser = $g_htpasswd_bin . ' -b ' . $g_htpasswd_file . ' \%1$s \%2$s';
$g_htpasswd_cmd_moduser = $g_htpasswd_bin . ' -b ' . $g_htpasswd_file . ' \%1$s \%2$s';
$g_htpasswd_cmd_deluser = $g_htpasswd_bin . ' -D ' . $g_htpasswd_file . ' \%1$s \%2$s';
?>
