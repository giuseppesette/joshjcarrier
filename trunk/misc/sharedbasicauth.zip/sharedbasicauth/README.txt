Shared Basic Authentication Integration
for
Mantis Bug Tracker, 1.2.1 
DokuWiki 2009-12-25c �Lemming� 
Mercurial 1.3.1+ 
==============================
Provides an integration point from DokuWiki to Mantis Bug Tracker,
and adds an automatic Basic HTTP Authentication htpasswd update, for
a service such as Mercurial.

Included are their relative installation directories.

Also included are the two configuration files which have been modified to accomodate
this integration. Compare them to your own. 
* Note: DokuWiki config changes may be erased when using the web-based config editor and must be re-applied manually *

More information available on the blog.
Last updated: 4/26/2010
==============================
Author: Josh Carrier <josh@joshjcarrier.com>
Web: <http://blog.joshjcarrier.com>