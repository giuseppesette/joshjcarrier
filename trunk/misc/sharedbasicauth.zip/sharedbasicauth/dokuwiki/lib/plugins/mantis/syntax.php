<?php
/**
 * Mantis Plugin: Hyperlinks references to Mantis Issues
 * 
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Victor Boctor (http://www.futureware.biz)
 */
 
 
if(!defined('DOKU_INC')) define('DOKU_INC',realpath(dirname(__FILE__).'/../../').'/');
if(!defined('DOKU_PLUGIN')) define('DOKU_PLUGIN',DOKU_INC.'lib/plugins/');
require_once(DOKU_PLUGIN.'syntax.php');
 
/**
 * A plug-in that hyper links references to Mantis issues.  References
 * to Mantis issues should use the following format: ~~Mantis:123~~.
 *
 * All DokuWiki plugins to extend the parser/rendering mechanism
 * need to inherit from this class
 */
class syntax_plugin_mantis extends DokuWiki_Syntax_Plugin {
 
    /**
     * return some info
     */
    function getInfo(){
        return array(
            'author' => 'Victor Boctor',
            'email'  => 'vboctor at users . sourceforge . net',
            'date'   => '2006-05-18',
            'name'   => 'Mantis Issues Plugin',
            'desc'   => 'Support References to Mantis Issues',
            'url'    => 'http://www.futureware.biz',
        );
    }
 
    /**
     * What kind of syntax are we?
     */
    function getType(){
        return 'substition';  # typo is intentional
    }
   
    /**
     * What about paragraphs?
     */
    function getPType(){
        return 'normal';
    }
 
    /**
     * Where to sort in?
     */ 
    function getSort(){
        return 156;
    }
 
 
    /**
     * Connect pattern to lexer
     */
    function connectTo($mode) {
        $this->Lexer->addSpecialPattern('~~Mantis:[0-9]+~~', $mode, 'plugin_mantis');
    }
 
 
    /**
     * Handle the match
     */
    function handle($match, $state, $pos, &$handler){
        $match = substr( $match, 9, -2 ); // strip "~~Mantis:" from start and "~~" from end
        return array( strtolower( $match ) );
    }
 
    /**
     * Create output
     */
    function render($format, &$renderer, $data) {
        if ( $format == 'xhtml' ) {
			$renderer->externallink( MANTIS_URL . 'view.php?id=' . $data[0], $data[0] );
            return true;
        }
        return false;
    }
}
?>