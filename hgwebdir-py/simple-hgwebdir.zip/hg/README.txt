Mercurial 1.5.1 CGI
for
Shared Hosting

Compiled for x86_64/Python2.4
==============================
Provides a way to host a Mercurial repository 
using an Apache web server and HTTP Basic Authentication.

More information available on the blog.
Last updated: 4/27/2010
==============================
Author: Josh Carrier <josh@joshjcarrier.com>
Web: <http://blog.joshjcarrier.com>